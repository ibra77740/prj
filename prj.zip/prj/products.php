<?php

session_start();

?>
<!DOCTYPE HTML>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require "account_functions.php" ;
$articles = get_all_articles();



?>
<html>
	<head>
		<title>produits</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css" integrity="sha512-rRQtF4V2wtAvXsou4iUAs2kXHi3Lj9NE7xJR77DE7GHsxgY9RTWy93dzMXgDIG8ToiRTD45VsDNdTiUagOFeZA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
		<link rel="stylesheet" href="card.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/purecss@3.0.0/build/pure-min.css" integrity="sha384-X38yfunGUhNzHpBaEBsWLO+A0HDYOQi8ufWDkZ0k9e0eXz/tH3II7uKZ9msv++Ls" crossorigin="anonymous">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
		<link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>

		<style>
			#banner {
				padding: 10em 0 4.75em 0 ;
				height: 400px;
				
			}
			.mega{
				
			}
			.signinbut:hover {
			background-color: rgb(71, 82, 196);
		}
		.logout{
				margin: 9px;
				transition: font-size 0.2s , color 0.2s;
				cursor: pointer;
			}
			.logout:hover{
				color: #e72e2e;
				font-size: 30px;
			}
		.signupbut {

display: inline-block;
	outline: none;
	cursor: pointer;
	border-radius: 3px;
	
	line-height: 16px;
	padding: 2px 16px;
	height: 38px;
	margin: 3px;
	min-width: 96px;
	min-height: 38px;
	font-size: 20px;
	font-weight: 900;
	border: none;
	color: #fff;
	background-color: rgb(88, 101, 242);
	transition: background-color .17s ease,color .17s ease;
   

}
.signinbut:hover {
		background-color: rgb(71, 82, 196);
	}
	.signinbut {

		display: inline-block;
			outline: none;
			cursor: pointer;
			border-radius: 3px;
			font-size: 20px;
			margin: 3px;
			font-weight: 900;
	

			line-height: 16px;
			padding: 2px 16px;
			height: 38px;
			min-width: 96px;
			min-height: 38px;
			border: none;
			color: #fff;
			background-color: rgb(0, 0, 0);
			transition: background-color .17s ease,color .17s ease;
		

		}
		.signinbut:hover {
				background-color: rgb(81, 81, 81);
			}
			</style>
	</head>
	<body class="is-preload">
		<div class="mynav ">
		<div class="rightnav ">
			<ul>
				<li id="home" class="home" >Acceul</li>
				<li id="products" class="selected">Produits</li>
				<li id="surdemande">sur demande</li>
			</ul>
		</div>
		<div class="searchcontainer ">
			<input type="text" class="searchinput" placeholder="rechercher...">
		</div>
		<div class="account pure-g">
		<?php 
				
				if(isset( $_SESSION['user'])){
					echo "<i class=\"fa-solid fa-right-from-bracket logout\"></i>";
					echo '<i class="fa-solid fa-bag-shopping card" id="panel"></i>';
					echo '<span class="username">';
					echo  $_SESSION['user']->nom." ". $_SESSION['user']->prenom ;
					echo '</span>';
					echo '<i class="fa-regular fa-user user"></i>';
				}else{
					echo '<button class="signupbut">sign up</button>';
					echo '<button class="signinbut">Sign in</button>';
				}



			?>
		</div>
		</div>
		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
				
					

				<!-- Menu -->
					<nav id="menu">
						<div class="inner">
							<h2>Menu</h2>
							<ul class="links">
								<li><a href="index.html">Home</a></li>
								<li><a href="generic.html">Generic</a></li>
								<li><a href="elements.html">Elements</a></li>
								<li><a href="#">Log In</a></li>
								<li><a href="#">Sign Up</a></li>
							</ul>
							<a href="#" class="close">Close</a>
						</div>
					</nav>

				<!-- Banner -->
					<section id="banner">
						<div class="pure-g filter">
							<div class="pure-u-1-4">
								<select name="form" id="form">
                                    <option value="categorie1">Poterie </option>
                                    <option value="categorie1">Tissage</option>
                                    <option value="categorie1"> Dinanderie</option>
                                    <option value="categorie1">ferronerie</option>
                                    <option value="categorie1">bijouterie</option>
                                    <option value="categorie1">maroquinerie</option>

                                </select>
							</div>
							<div class="pure-u-1-4">
								
									<input type="month" class="dat" placeholder="date">
	
								
							</div>
							<div class="pure-u-1-4">
								<input type="text" placeholder="place">
							</div>
							<div class="pure-u-1-4">
								<div class="pricewrapper">
									
									<div class="price-input">
									  <div class="field">
										<span>Min</span>
										<input type="number" class="input-min" value="2500">
									  </div>
									  <div class="separator">-</div>
									  <div class="field">
										<span>Max</span>
										<input type="number" class="input-max" value="7500">
									  </div>
									</div>
									<div class="slider">
									  <div class="progress"></div>
									</div>
									<div class="range-input">
									  <input type="range" class="range-min" min="0" max="10000" value="2500" step="100">
									  <input type="range" class="range-max" min="0" max="10000" value="7500" step="100">
									</div>
								  </div>
							</div>
							
						
								
							
						</div>
						<button class="filtersearch">search</button>
					</section>

				<!-- Wrapper -->
					

						<!-- Four -->
							<section id="four" class="wrapper alt style1 productlist">
								<div class="cardcontainer">
									
								

										<?php


												foreach ($articles as $key => $val) {
														
														echo '<div class="shell">';
														echo '<div class="container">';
														echo '<div class="row">';
														echo '<div class="col-md-3">';
														echo '<div class="wsk-cp-product">';
														echo '<div class="wsk-cp-img">';
														echo '<img src="'.$val['imgArt'].'" alt="Product" class="img-responsive mega" />';
														echo '</div>';
														echo '<div class="wsk-cp-text">';
														echo '<div class="category">';
														echo '<span>'.$val['categorie'].'</span>';
														echo '</div>';
														echo '<div class="title-prosduct">';
														echo '<h3>'.$val['nom'].'</h3>';
														echo '</div>';
														echo '<div class="description-prod">';
														echo '<p>'.$val['desc'].'</p>';
														echo '</div>';
														echo '<div class="card-footer">';
														echo '<div class="wcf-left"><span class="price">'.$val['prix'].' DH</span></div>';
														echo '<div class="wcf-right"><a href="http://localhost/roma/info.php?id='.$val['id'].'"  class="buy-btn"><i class="zmdi zmdi-shopping-basket"></i></a></div>';
														echo '</div>';
														echo '</div>';
														echo '</div>';
														echo '</div>';
														echo '';
														echo '</div>';
														echo '</div>';
														echo '</div>';
													
												}

										
								?>
									
								</div>
								
								
									
							</section>
							<footer>
								<div class="footer">
								<div class="row social">
								<a href="#"><i  class="fa-brands fa-facebook"></i></a>
								<a href="#"><i class="fa-brands fa-instagram"></i></a>
								<a href="#"><i class="fa-brands fa-youtube"></i></a>
								<a href="#"><i class="fa-brands fa-twitter"></i></a>
								</div>
								
								<div class="row links">
								<ul>
								<li><a href="#">Nous contacter</a></li>
								<li><a href="#">Our Services</a></li>
								<li><a href="#">Politique de confidentialité</a></li>
								<li><a href="#">termes et conditions</a></li>
								<li><a href="#">Career</a></li>
								</ul>
								</div>
								
								<div class="row">
								2023 || Designed By: master sid
								</div>
								</div>
								</footer>
					

				

							














					
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
			<script>
				const rangeInput = document.querySelectorAll(".range-input input"),
				priceInput = document.querySelectorAll(".price-input input"),
				range = document.querySelector(".slider .progress");
				let priceGap = 1000;
				priceInput.forEach(input =>{
					input.addEventListener("input", e =>{
						let minPrice = parseInt(priceInput[0].value),
						maxPrice = parseInt(priceInput[1].value);
						
						if((maxPrice - minPrice >= priceGap) && maxPrice <= rangeInput[1].max){
							if(e.target.className === "input-min"){
								rangeInput[0].value = minPrice;
								range.style.left = ((minPrice / rangeInput[0].max) * 100) + "%";
							}else{
								rangeInput[1].value = maxPrice;
								range.style.right = 100 - (maxPrice / rangeInput[1].max) * 100 + "%";
							}
						}
					});
				});
				rangeInput.forEach(input =>{
					input.addEventListener("input", e =>{
						let minVal = parseInt(rangeInput[0].value),
						maxVal = parseInt(rangeInput[1].value);
						if((maxVal - minVal) < priceGap){
							if(e.target.className === "range-min"){
								rangeInput[0].value = maxVal - priceGap
							}else{
								rangeInput[1].value = minVal + priceGap;
							}
						}else{
							priceInput[0].value = minVal;
							priceInput[1].value = maxVal;
							range.style.left = ((minVal / rangeInput[0].max) * 100) + "%";
							range.style.right = 100 - (maxVal / rangeInput[1].max) * 100 + "%";
						}
					});
				});
			</script>

	</body>
</html>