<?php
require "class/user.php" ;
require "class/shop.php" ;

function save_user_data($data){
   $myjson = json_encode($data);


   $myfile = fopen("users.json","w");
   fwrite($myfile,$myjson);
   fclose($myfile);
}
function save_articl_data($data){
   $myjson = json_encode($data);


   $myfile = fopen("articles.json","w");
   fwrite($myfile,$myjson);
   fclose($myfile);
}



function getUserByEmail($email,$data){
   foreach ($data as $key => $val) {
    
      if ($val['email'] == $email) {
         return $key;
      }
   }
   return null;
}



function getUserByBirthday($date,$data){
   foreach($data as $key => $val){
      if($val['date'] == $date ){
         $users[]=$key ;
      }
   }

   if(count($users)==0){
      return null ;
   }else{
      return $users ;
   }

}

function sign_up($nom,$prenom,$email,$password,$adr,$date){
   $panel=[];
   $histo=[];
   $fav=[];
  

   $newUser = new User($nom,$prenom,$email,$password,$adr,$date,$panel,$histo,$fav);
 
   $json = file_get_contents('users.json');

   $data = json_decode($json , true);

   $myUser = (array) $newUser;

   $data[] = $myUser;
   
   save_user_data($data);

   return 0 ;
}

// sign_up("ahkouk","ibrahim","ahkoukibrahim@gmail.com","123456","rabat yacoub mensour","17/12/2000");
// sign_up("ackraman","mikasa","ackramanmikasa@gmail.com","987654","japon tokyo","15/12/2000");

function sign_in($email,$password){

   $json = file_get_contents('users.json');

   $data = json_decode($json , true) ;

   $res = getUserbyEmail($email,$data);

   if($res===null){
      return null ;
   }else{

      if($data[$res]['password']!=$password){
         return null ;
      }else{
        $user = (object)$data[$res];
        return $user ;
      }


   }

}

function delete_account($email,$password){

   $json = file_get_contents('users.json');

   $data = json_decode($json , true) ;

   $res = getUserbyEmail($email,$data);

   if($res===null){
      return -1 ;
   }else{

      if($data[$res]['password']!=$password){
         return -2 ;
      }else{
         unset($data[$res]);
         save_user_data($data);

      }


   }
   
}

function get_all_articles(){
   $json = file_get_contents('articles.json');

   $data = json_decode($json , true) ;

   return $data;
}

function get_article_by_id($id){
   $json = file_get_contents('articles.json');

   $data = json_decode($json , true) ;
   foreach ($data as $key => $val) {
    
      if ($val['id'] == $id) {
         
         return $val;
      }
   }
   return null;
}








?>