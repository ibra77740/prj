<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);





?>

<!DOCTYPE HTML>

<html>
	<head>
		<title>Acceuil</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/purecss@3.0.0/build/pure-min.css" integrity="sha384-X38yfunGUhNzHpBaEBsWLO+A0HDYOQi8ufWDkZ0k9e0eXz/tH3II7uKZ9msv++Ls" crossorigin="anonymous">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
		<style>
			.logout{
				margin: 9px;
				transition: font-size 0.2s , color 0.2s;
				cursor: pointer;
			}
			.logout:hover{
				color: #e72e2e;
				font-size: 30px;
			}
			.logoname{
				width: 500px;
			}
			.logox{
				margin-top: 15px;
				width: 60px;
			}
			.hoverimage{
				background-color: brown;
	 		 }
			.catx{
				width: 400px;
				border-radius: 50%;
				position: relative;
				right: -100px;
				transition: width .5s;
				cursor: pointer;
			}
			.catx:hover{
				width: 500px;
			}

			.leftcatx{
				width: 400px;
				border-radius: 50%;
				position: relative;
				left: -100px;
				transition: width .5s;
				cursor: pointer;
			}
			.leftcatx:hover{
				width: 500px;
			}
			
			
			.signupbut {

				display: inline-block;
                    outline: none;
                    cursor: pointer;
                    border-radius: 3px;
                    
                    line-height: 16px;
                    padding: 2px 16px;
                    height: 38px;
					margin: 3px;
                    min-width: 96px;
                    min-height: 38px;
					font-size: 20px;
					font-weight: 900;
                    border: none;
                    color: #fff;
                    background-color: rgb(88, 101, 242);
                    transition: background-color .17s ease,color .17s ease;
                   
                
			}
			.signinbut:hover {
                        background-color: rgb(71, 82, 196);
                    }
					.signinbut {

						display: inline-block;
							outline: none;
							cursor: pointer;
							border-radius: 3px;
							font-size: 20px;
							margin: 3px;
							font-weight: 900;
					

							line-height: 16px;
							padding: 2px 16px;
							height: 38px;
							min-width: 96px;
							min-height: 38px;
							border: none;
							color: #fff;
							background-color: rgb(0, 0, 0);
							transition: background-color .17s ease,color .17s ease;
						

						}
						.signinbut:hover {
								background-color: rgb(81, 81, 81);
							}
		</style>
	</head>
	<body class="is-preload">
		<div class="mynav ">
		<div class="rightnav ">
			<ul>
				<li id="home" class="selected">Acceul</li>
				<li id="products" >Produits</li>
				<li id="surdemande">sur demande</li>
			</ul>
		</div>
		<div class="searchcontainer ">
			<input type="text" class="searchinput" placeholder="rechercher...">
		</div>
		<div class="account pure-g">
			<?php 
				
				if(isset( $_SESSION['user'])){
					echo "<i class=\"fa-solid fa-right-from-bracket logout \"></i>";
					echo '<i class="fa-solid fa-bag-shopping card" id="panel"></i>';
					echo '<span class="username">';
					echo  $_SESSION['user']->nom." ". $_SESSION['user']->prenom ;
					echo '</span>';
					echo '<i class="fa-regular fa-user user"></i>';
				}else{
					echo '<button class="signupbut">s\'inscrire</button>';
					echo '<button class="signinbut">se connecter</button>';
				}



			?>


			
			
		</div>
		</div>
		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
				
					

				<!-- Menu -->
					

				<!-- Banner -->
					<section id="banner">
						<div class="inner">
							<div class="logo"><span class="icon"><img class="logox" src="logo.png" alt=""></span></div>
							<h2><img class="logoname" src="logoname.png" alt=""></h2>
							<p>Nous considérons l'artisanat comme une des formes exemplaires de l'activité humaine.</p>
						</div>
					</section>

				<!-- Wrapper -->
					<section id="wrapper">

						<!-- One -->
							<section id="one" class="wrapper spotlight style1">
								<div class="inner">
									<img class="catx" src="c1.jpg" alt="">
									<div class="content">
										<h2 class="major">Catégorie 1 : Poterie </h2>
										<p>
										Cet art ancestral qu’est la poterie au Maroc est ancré depuis des siècles, ce sont les Maures il y a plus de 1000 ans qui ont installés les premiers fours à Fès, Meknès, Safi et Marrakech.

											La poterie au Maroc est une pure tradition marocaine transmise de générations en générations. 
											On peut ainsi dire que la poterie au Maroc est un véritable art de vivre ! 

											L’histoire de la poterie au Maroc est très riche et variée mais, tout comme le temps, elle a dû se confronter à de nouveaux concepts avec pour objectif d’évoluer et de s’adapter aux nouvelles tendances, utilitaires comme décoratives tout en conservant toute son authenticité.
											Ainsi, toujours teintée de culture locale, la poterie se diversifie et notamment entre le nord et le sud du royaume, de même entre les villes et les villages ruraux, c’est cette diversité qui fait valoir les belles poteries du maroc, poteries citadines et poteries berbères. Née de cet héritage très ancien, cette poterie marocaine et berbère séduit toujours de toutes les particularités qu’elle peut faire valoir.
																					</p>
										<a href="#" class="special">voir plus</a>

									</div>
								</div>
							</section>

						<!-- Two -->
							<section id="two" class="wrapper alt spotlight style2">
								<div class="inner">
								<img class="leftcatx" src="c2.jpg" alt="">									<div class="content">
										<h2 class="major">Catégorie 2 : Tissage</h2>
										<p>
										L’art du tissage traditionnel marocain est un art ancestral. Il utilise notamment des produits de soie, de laine et de coton. Le tapis marocain pour sa part, se caractérise par sa beauté, sa diversité, la vivacité de ses couleurs et par la laine comme matière première. Cette laine filée à la main qui, par sa finesse donne tout le charme au tapis marocain.
										</p>
										<a href="#" class="special">voir plus</a>
									</div>
								</div>
							</section>

						<!-- Three -->
							<section id="three" class="wrapper spotlight style3">
								<div class="inner">
									<img class="catx" src="c3.jpg" alt="">
									<div class="content">
										<h2 class="major">Catégorie 3 : Dinanderie</h2>
										<p>
										La dinanderie apparût au Maroc au XIIe siècle et devient une véritable spécialité à partir du XIVe siècle. Elle désigne le travail artistique du cuivre, du laiton, de l’argent, du plomb, du fer-blanc, de l’étain, du maillechort ou de l’aluminium, au moyen de différents outils dont principalement les marteaux. Les artisans font fondre le métal, puis le martèlent ou le cisèlent pour fabriquer des objets utilitaires et décoratifs, fascinants, fruits du génie et savoir-faire des Maâllems marocains : plateaux ronds « Soigni », des bouilloires, des théières, des boîtes à thé et sucre, des chandeliers, des casseroles, des luminaires, des marmites, des fontaines en cuivre …etc.
										</p>
										<a href="#" class="special">voir plus</a>
									</div>
								</div>
							</section>
							<!-- Two -->
							<section id="two" class="wrapper alt spotlight style2">
								<div class="inner">
								<img class="leftcatx" src="c4.jpg" alt="">
									<div class="content">
										<h2 class="major">Catégorie 4 : ferronerie</h2>
										<p>
										Le travail du fer est une discipline très ancienne, nous retrouvons ses premières traces environ 1800 ans av. J.-C.. La connaissance de la métallurgie et la maitrise du feu ont largement contribué à cela. En effet, le fer est un métal dur à l’état naturel, mais qui devient malléable au contact du feu. C’est cette caractéristique qui a séduit les premiers forgerons des civilisations anciennes. Au Maroc, le fer forgé fait partie de la vie des habitants à partir du XIV° siècle. Des fourneaux ont été retrouvés à la région de Demnate, environ 160 kms d’Ouarzazate.

Le fer forgé est très présent en des éléments de l’architecture marocaine. Nous retrouvons de belles grilles au niveau des portes, des portails, des portillons, des fenêtres, balustrade, des paravents pour séparer les pièces… Il est également présent dans le mobilier, canapé, fauteuils, table, banquette de salon, de jardin ou des accessoires de décoration comme les lampes, les lanternes, les bougeoirs, des miroirs murales… Les artisans ferronniers ne cessent d’user de leur talon et leur imagination pour produire des pièces originales.
										</p>
										<a href="#" class="special">voir plus</a>
									</div>
								</div>
							</section>

						<!-- Three -->
							<section id="three" class="wrapper spotlight style3">
								<div class="inner">
									<img class="catx" src="c5.jpg" alt="">
									<div class="content">
										<h2 class="major">Catégorie 5 : bijouterie </h2>
										<p>
										la bijouterie marocaine, cet extraordinaire héritage artistique et culturel, transmis de génération en génération, constitue « un prodige » de l’artisanat marocain, où tradition et modernité se côtoient pour donner naissance à des chefs d’œuvre d’exception.

Façonnés à la main avec des techniques ancestrales, les bijoux marocains qui se distinguent par leur charme indéniable, portent une forte charge culturelle et esthétique, témoignant d’un brassage millénaire des différentes civilisations qui se sont succédé dans le Royaume.

La diversité et la richesse des formes, des géométries, des modèles, des perles et des symboles, illustre parfaitement la beauté et la splendeur de la bijouterie nationale et confirme, ainsi, le talent remarquable et le savoir- faire éblouissant de l’artisan marocain.
										</p>
										<a href="#" class="special">voir plus</a>
									</div>
								</div>
							</section>
							<!-- Two -->
							<section id="two" class="wrapper alt spotlight style2">
								<div class="inner">
								<img class="leftcatx" src="c6.jpg" alt="">
									<div class="content">
										<h2 class="major">Catégorie 6 : maroquinerie</h2>
										<p>
										Le cuir est l’un des produits connus depuis l’Antiquité. Les archéologues ont retrouvé des sculptures égyptiennes qui représentent des artisans en train de travailler le cuir. De plus, des restes de cuir d’il y a environ 6000 ans ont fait l’objet de découverte.

Le processus où la peau est travaillée pour obtenir du cuir s’est amélioré au fur et à mesure. Au départ, la peau était utilisée sans beaucoup de traitement, juste en exposant la peau au soleil et l’air libre. Par la suite, différentes huiles ont été introduites et également des matériaux naturels comme les feuilles, les branches, les écorces trempées dans l’eau afin de mieux préserver la peau.

Aujourd’hui, la découverte de méthodes chimiques facilite largement cette étape.
										</p>
										<a href="#" class="special">voir plus</a>
									</div>
								</div>
							</section>


						<!-- Four -->
							<section id="four" class="wrapper alt style1">
								<div class="inner">
									<h2 class="major">Evenements</h2>
									<section class="features">
										<article>
											<a href="#" class="image"><img src="images/pic04.jpg" alt="" /></a>
											
											<p>A Ouarzazate et ses environs, et notamment aux ateliers de Taznakht et d’Ait Ouazguite, les artisanes confectionnent à la main les somptueux tapis Kharita et Chedwi. Au milieu des métiers à tisser, des rouets et des tas de laine, vous découvrirez comment chaque tapis devient un spécimen unique, qui reflète avant tout la sensibilité et le savoir-faire de la tisseuse. Il en est de même à Midelt, qui abrite la coopérative Andaz Nouska, réputée pour produire les meilleurs tapis et broderies du Haut-Atlas Oriental.</p>

											<a href="#" class="special">voir plus</a>
										</article>
										<article>
											<a href="#" class="image"><img src="e3.webp" alt="" /></a>
											
											<p>Tandis qu’à Tinghir, prenez le temps de visiter les ateliers de fabrication des magnifiques soufflets, emblème de la ville. Là, des artisans pluridisciplinaires taillent puis assemblent des pièces de diverses matières, pour concevoir un outil aussi indispensable que joli.
</p>
											<a href="#" class="special">voir plus</a>
										</article>
										<article>
											<a href="#" class="image"><img src="e1.jpg" alt="" /></a>
											
											<p>La poterie quant à elle, est une des formes artisanales des plus répandues dans la Région. On en trouve à Tamegroute, connue pour sa poterie verte, mais également au village des potiers de Gueddara près de Skoura et celui de Tadigouste à Goulmima. Chaque atelier adopte un procédé différent, donnant aux produits un charme unique et un attrait de rareté. </p>
											<a href="#" class="special">voir plus</a>
										</article>
										<article>
											<a href="#" class="image"><img src="e2.jpg" alt="" /></a>
											
											<p>A Erfoud , c’est l’artisanat des fossiles qui domine la place. Plusieurs ateliers y transforment des plaques de marbre contenant plusieurs types de fossiles, en objets décoratifs de toute taille. Sans oublier les ateliers d’Azlag, où raisonnent les coups de marteaux et de piques, donnant vie aux célèbres poignards courbés en argent.</p>
											<a href="#" class="special">voir plus</a>
										</article>
									</section>
									<ul class="actions">
										<li><a href="#" class="button">autre</a></li>
									</ul>
								</div>
							</section>

					</section>

				




					<footer>
								<div class="footer">
								<div class="row social">
								<a href="#"><i  class="fa-brands fa-facebook"></i></a>
								<a href="#"><i class="fa-brands fa-instagram"></i></a>
								<a href="#"><i class="fa-brands fa-youtube"></i></a>
								<a href="#"><i class="fa-brands fa-twitter"></i></a>
								</div>
								
								<div class="row links">
								<ul>
								<li><a href="#">Nous contacter</a></li>
								<li><a href="#">Our Services</a></li>
								<li><a href="#">Politique de confidentialité</a></li>
								<li><a href="#">termes et conditions</a></li>
								<li><a href="#">Career</a></li>
								</ul>
								</div>
								
								<div class="row">
								2023 || Designed By: master sid
								</div>
								</div>
								</footer>










					
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>